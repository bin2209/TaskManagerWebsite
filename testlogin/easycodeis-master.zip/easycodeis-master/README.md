# easycodeis

### Live Website -> https://easycodeis.com

### Code Setup
1. Checkout repo to easycodeis folder in www/ directory

### Database Setup
1. Import database structure from easycodeis.sql

### config.php Setup
1. Open up config_template.php and follow the steps for setup.

### Tutorials
- YouTube -> https://youtube.com/justinstolpe
- Blog -> https://justinstolpe.com/blog/
- My Website -> https://justinstolpe.com

==========================================================================
    
                  (           (        )   (               )   (     (         
                  )\ )  *   ) )\ )  ( /(   )\ )  *   )  ( /(   )\ )  )\ )      
       (      (  (()/(` )  /((()/(  )\()) (()/(` )  /(  )\()) (()/( (()/( (    
       )\     )\  /(_))( )(_))/(_))((_)\   /(_))( )(_))((_)\   /(_)) /(_)))\   
      ((_) _ ((_)(_)) (_(_())(_))   _((_) (_)) (_(_())   ((_) (_))  (_)) ((_)  
     _ | || | | |/ __||_   _||_ _| | \| | / __||_   _|  / _ \ | |   | _ \| __| 
    | || || |_| |\__ \  | |   | |  | .` | \__ \  | |   | (_) || |__ |  _/| _|  
     \__/  \___/ |___/  |_|  |___| |_|\_| |___/  |_|    \___/ |____||_|  |___|
